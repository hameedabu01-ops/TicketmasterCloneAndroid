package com.example.ticketmasterdemo

import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

private val TMBlue = Color(0xFF026CDF)
private val Navy = Color(0xFF071A3D)
private val Pale = Color(0xFFF4F7FB)
private val Ink = Color(0xFF17233D)
private val Muted = Color(0xFF596579)
private const val PREFS = "ticketmaster_demo"

data class EventItem(
    val id: String,
    val name: String,
    val date: String,
    val venue: String,
    val city: String,
    val category: String,
    val price: String,
    val eventUrl: String = "https://www.ticketmaster.com/",
    val imageUrl: String = ""
)

data class DemoTicket(
    val orderId: String,
    val eventId: String,
    val eventName: String,
    val date: String,
    val venue: String,
    val city: String,
    val category: String,
    val quantity: Int,
    val total: Double,
    val holder: String,
    val email: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TicketmasterApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketmasterApp(context: Context) {
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var city by remember { mutableStateOf(prefs.getString("city", "New York") ?: "New York") }
    var category by remember { mutableStateOf("All") }
    var events by remember { mutableStateOf(sampleEvents()) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Sample events are shown. Add an API key to load live listings.") }
    var selected by remember { mutableStateOf<EventItem?>(null) }
    var checkout by remember { mutableStateOf(false) }
    var confirmation by remember { mutableStateOf<DemoTicket?>(null) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()) }
    var tickets by remember { mutableStateOf(loadTickets(prefs)) }
    var profileName by remember { mutableStateOf(prefs.getString("name", "Demo Guest") ?: "Demo Guest") }

    fun persistFavorites() { prefs.edit().putStringSet("favorites", favorites.toSet()).apply() }
    fun persistTickets() { saveTickets(prefs, tickets) }
    fun refreshEvents(search: String = query, location: String = city) {
        if (BuildConfig.TICKETMASTER_API_KEY.isBlank()) {
            val all = sampleEvents()
            events = all.filter { (search.isBlank() || it.name.contains(search, true) || it.category.contains(search, true) || it.venue.contains(search, true)) && (location.isBlank() || it.city.contains(location, true) || all.none { e -> e.city.contains(location, true) }) }
            status = "Demo listings • Live events require a Ticketmaster API key."
            return
        }
        loading = true; status = "Loading events…"
        thread {
            try {
                val q = URLEncoder.encode(search, "UTF-8")
                val loc = URLEncoder.encode(location, "UTF-8")
                val endpoint = "https://app.ticketmaster.com/discovery/v2/events.json?apikey=${BuildConfig.TICKETMASTER_API_KEY}&city=$loc&keyword=$q&size=40&sort=date,asc"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply { connectTimeout = 12000; readTimeout = 12000; requestMethod = "GET" }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw IllegalStateException("API response $code")
                val array = JSONObject(body).optJSONObject("_embedded")?.optJSONArray("events")
                val result = mutableListOf<EventItem>()
                if (array != null) for (i in 0 until array.length()) {
                    val e = array.getJSONObject(i)
                    val start = e.optJSONObject("dates")?.optJSONObject("start")
                    val date = start?.optString("localDate", "Date TBA") ?: "Date TBA"
                    val venue = e.optJSONObject("_embedded")?.optJSONArray("venues")?.optJSONObject(0)
                    val venueName = venue?.optString("name", "Venue TBA") ?: "Venue TBA"
                    val eventCity = venue?.optJSONObject("city")?.optString("name", location) ?: location
                    val type = e.optJSONArray("classifications")?.optJSONObject(0)?.optJSONObject("segment")?.optString("name", "Live event") ?: "Live event"
                    val ranges = e.optJSONArray("priceRanges")
                    val price = if (ranges != null && ranges.length() > 0) { val p = ranges.getJSONObject(0); "${p.optString("currency", "")} ${p.optDouble("min", 0.0).toInt()}+" } else "See official listing"
                    val images = e.optJSONArray("images")
                    val imageUrl = if (images != null && images.length() > 0) images.optJSONObject(0)?.optString("url", "") ?: "" else ""
                    result.add(EventItem(e.optString("id"), e.optString("name", "Live event"), date, venueName, eventCity, type, price, e.optString("url", "https://www.ticketmaster.com/"), imageUrl))
                }
                Handler(Looper.getMainLooper()).post { events = result; status = if (result.isEmpty()) "No events found. Try another search or city." else "Live Ticketmaster listings"; loading = false }
            } catch (_: Exception) {
                Handler(Looper.getMainLooper()).post { status = "Could not load live events. Check connection and API key."; loading = false }
            }
        }
    }

    fun sendEmail(event: EventItem) {
        val subject = "Event to check out: ${event.name}"
        val body = "I thought you might be interested in this event:\n\n${event.name}\n${event.date}\n${event.venue}, ${event.city}\n\nEvent listing: ${event.eventUrl}\n\nShared from a Ticketmaster-style hackathon demo."
        val intent = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("mailto:"); putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, body) }
        try { context.startActivity(Intent.createChooser(intent, "Email event link")) } catch (_: Exception) { }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = TMBlue, background = Pale, surface = Color.White)) {
        Scaffold(containerColor = Pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Home", "Search", "Favorites", "My Tickets", "Profile").forEach { item ->
                    val icon = when (item) { "Home" -> Icons.Default.Home; "Search" -> Icons.Default.Search; "Favorites" -> Icons.Default.Favorite; "My Tickets" -> Icons.Default.ConfirmationNumber; else -> Icons.Default.Person }
                    NavigationBarItem(selected = tab == item, onClick = { tab = item; selected = null; checkout = false; confirmation = null }, icon = { Icon(icon, contentDescription = item) }, label = { Text(item, fontSize = 9.sp) })
                }
            }
        }) { padding ->
            when {
                confirmation != null -> ConfirmationScreen(confirmation!!, onTickets = { confirmation = null; selected = null; checkout = false; tab = "My Tickets" }, onHome = { confirmation = null; selected = null; checkout = false; tab = "Home" })
                selected != null && checkout -> CheckoutScreen(selected!!, onBack = { checkout = false }, onComplete = { holder, email, quantity, total, ticketCategory ->
                    val event = selected!!
                    val ticket = DemoTicket(UUID.randomUUID().toString().take(8).uppercase(Locale.ROOT), event.id, event.name, event.date, event.venue, event.city, ticketCategory, quantity, total, holder, email)
                    tickets = tickets + ticket; persistTickets(); confirmation = ticket; checkout = false
                })
                selected != null -> EventDetailsScreen(selected!!, isFavorite = favorites.contains(selected!!.id), onBack = { selected = null }, onFavorite = { favorites = favorites.toMutableSet().apply { if (contains(selected!!.id)) remove(selected!!.id) else add(selected!!.id) }; persistFavorites() }, onEmail = { sendEmail(selected!!) }, onBook = { checkout = true })
                else -> when (tab) {
                    "Home" -> HomeScreen(padding, query, { query = it }, city, { city = it; prefs.edit().putString("city", it).apply() }, events, favorites, loading, status, category, { category = it }, { refreshEvents() }, { selected = it }, { e -> favorites = favorites.toMutableSet().apply { if (contains(e.id)) remove(e.id) else add(e.id) }; persistFavorites() })
                    "Search" -> SearchScreen(padding, query, { query = it }, category, { category = it }, events, { refreshEvents() }, { selected = it })
                    "Favorites" -> {
                        HeaderScreen(padding, "Favorites", "Events you have saved")
                        val list = events.filter { favorites.contains(it.id) }
                        if (list.isEmpty()) EmptyState("No favorites yet", "Tap the heart on an event to save it.") else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { EventCard(it, true, { favorites = favorites.toMutableSet().apply { remove(it.id) }; persistFavorites() }, { selected = it }) } }
                    }
                    "My Tickets" -> {
                        HeaderScreen(padding, "My Tickets", "Your event tickets")
                        if (tickets.isEmpty()) EmptyState("No tickets yet", "Choose an event and complete a demo checkout.") else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(tickets.reversed()) { TicketCard(it, onEmail = { t -> sendEmail(EventItem(t.eventId, t.eventName, t.date, t.venue, t.city, t.category, "Demo order", "https://www.ticketmaster.com/")) }) } }
                    }
                    else -> ProfileScreen(padding, profileName, { profileName = it; prefs.edit().putString("name", it).apply() }, city, { city = it; prefs.edit().putString("city", it).apply() })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, query: String, onQuery: (String) -> Unit, city: String, onCity: (String) -> Unit, events: List<EventItem>, favorites: Set<String>, loading: Boolean, status: String, category: String, onCategory: (String) -> Unit, onRefresh: () -> Unit, onSelect: (EventItem) -> Unit, onFavorite: (EventItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp)) {
            Text("ticketmaster", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
            Spacer(Modifier.height(14.dp))
            Text("Find your next live moment", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search artists, teams, events") }, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { IconButton(onClick = onRefresh) { Icon(Icons.Default.ArrowForward, null) } }, singleLine = true, shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedTextColor = Ink, unfocusedTextColor = Ink, focusedBorderColor = TMBlue, unfocusedBorderColor = Color.White))
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocationOn, null, tint = Color.White); Spacer(Modifier.width(6.dp)); Text("Near", color = Color.White); Spacer(Modifier.width(8.dp)); OutlinedTextField(value = city, onValueChange = onCity, modifier = Modifier.weight(1f).height(52.dp), singleLine = true, placeholder = { Text("City") }, colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedTextColor = Ink, unfocusedTextColor = Ink, focusedBorderColor = TMBlue, unfocusedBorderColor = Color.White)); IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Color.White) } }
        }
        CategoryChips(category, onCategory)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Events you might like", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink); TextButton(onClick = onRefresh) { Text("Refresh") } }
        Text(status, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp), color = Muted, fontSize = 11.sp)
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        val filtered = events.filter { (category == "All" || it.category.contains(category, true) || (category == "Music" && it.category.contains("concert", true))) && (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true) || it.venue.contains(query, true)) }
        if (filtered.isEmpty() && !loading) EmptyState("No matching events", "Try another search or choose All categories.") else LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(filtered) { EventCard(it, favorites.contains(it.id), { onFavorite(it) }, { onSelect(it) }) } }
    }
}

@Composable
private fun SearchScreen(padding: PaddingValues, query: String, onQuery: (String) -> Unit, category: String, onCategory: (String) -> Unit, events: List<EventItem>, onRefresh: () -> Unit, onSelect: (EventItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(18.dp)) { Text("Search events", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Artist, team, venue or event") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedTextColor = Ink, unfocusedTextColor = Ink)) }
        CategoryChips(category, onCategory)
        TextButton(onClick = onRefresh, modifier = Modifier.align(Alignment.End).padding(end = 12.dp)) { Icon(Icons.Default.Refresh, null); Text("Search live events") }
        val result = events.filter { (query.isBlank() || it.name.contains(query, true) || it.venue.contains(query, true) || it.city.contains(query, true) || it.category.contains(query, true)) && (category == "All" || it.category.contains(category, true)) }
        if (result.isEmpty()) EmptyState("No results", "Try a different event name or category.") else LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { items(result) { EventCard(it, false, {}, { onSelect(it) }) } }
    }
}

@Composable
private fun CategoryChips(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        listOf("All", "Music", "Sports", "Theatre", "Comedy").forEach { item -> FilterChip(selected = selected == item, onClick = { onSelect(item) }, label = { Text(item, fontSize = 11.sp) }, leadingIcon = if (selected == item) ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp)) }) else null) }
    }
}

@Composable
private fun EventCard(event: EventItem, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(110.dp).background(Brush.horizontalGradient(listOf(Navy, TMBlue))), contentAlignment = Alignment.CenterStart) {
                if (event.imageUrl.isNotBlank()) AsyncImage(model = event.imageUrl, contentDescription = event.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Navy.copy(alpha = 0.78f), TMBlue.copy(alpha = 0.35f)))))
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ConfirmationNumber, null, tint = Color.White, modifier = Modifier.size(34.dp)); Spacer(Modifier.width(12.dp)); Column { Text(event.category.uppercase(Locale.getDefault()), color = Color(0xFFDCEAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp); Text("LIVE EVENTS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold) } }
                IconButton(onClick = onFavorite, modifier = Modifier.align(Alignment.TopEnd)) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFFFD2DD) else Color.White) }
            }
            Column(Modifier.padding(15.dp)) {
                Text(event.name, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null, tint = TMBlue, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(event.date, color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.height(5.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Place, null, tint = TMBlue, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("${event.venue} • ${event.city}", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(event.price, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("See tickets  →", color = TMBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun EventDetailsScreen(event: EventItem, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit, onEmail: () -> Unit, onBook: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Pale)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Text("Event details", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.weight(1f)); IconButton(onClick = onFavorite) { Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color.White) }; IconButton(onClick = onEmail) { Icon(Icons.Default.Share, null, tint = Color.White) } }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            item { Box(Modifier.fillMaxWidth().height(175.dp).background(Brush.linearGradient(listOf(TMBlue, Navy))), contentAlignment = Alignment.Center) { if (event.imageUrl.isNotBlank()) AsyncImage(model = event.imageUrl, contentDescription = event.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop); Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy.copy(alpha = 0.15f), Navy.copy(alpha = 0.65f))))); Icon(Icons.Default.ConfirmationNumber, null, tint = Color.White, modifier = Modifier.size(78.dp)) } }
            item { Column(Modifier.padding(20.dp)) { Text(event.category.uppercase(), color = TMBlue, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.4.sp); Spacer(Modifier.height(8.dp)); Text(event.name, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 27.sp, lineHeight = 31.sp); Spacer(Modifier.height(16.dp)); DetailLine(Icons.Default.CalendarMonth, "Date", event.date); DetailLine(Icons.Default.Place, "Venue", event.venue); DetailLine(Icons.Default.LocationCity, "Location", event.city); DetailLine(Icons.Default.Payments, "Price information", event.price); Spacer(Modifier.height(12.dp)); Text("About this event", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.height(6.dp)); Text("Explore this live event and choose a ticket option. Availability and pricing in this demonstration may be simulated. Check the official listing for confirmed details.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp); Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = onEmail, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Email, null); Spacer(Modifier.width(8.dp)); Text("Email event link") } } }
        }
        Button(onClick = onBook, modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp), shape = RoundedCornerShape(12.dp)) { Text("Get Tickets", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

@Composable
private fun CheckoutScreen(event: EventItem, onBack: () -> Unit, onComplete: (String, String, Int, Double, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(1) }
    var category by remember { mutableStateOf("Standard") }
    var error by remember { mutableStateOf("") }
    val unitPrice = when (category) { "Premium" -> 95.0; "VIP" -> 150.0; else -> 55.0 }
    val subtotal = unitPrice * quantity
    val fee = subtotal * 0.12
    val tax = subtotal * 0.05
    val total = subtotal + fee + tax
    Column(Modifier.fillMaxSize().background(Pale)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Text("Checkout", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(16.dp)) { Text("ORDER SUMMARY", color = TMBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp); Spacer(Modifier.height(7.dp)); Text(event.name, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("${event.date} • ${event.venue}, ${event.city}", color = Muted, fontSize = 12.sp) } } }
            item { Text("Choose tickets", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            item { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Standard", "Premium", "VIP").forEach { tier -> Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).clickable { category = tier }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = category == tier, onClick = { category = tier }); Column(Modifier.weight(1f)) { Text(tier, color = Ink, fontWeight = FontWeight.SemiBold); Text(if (tier == "Standard") "General admission" else if (tier == "Premium") "Preferred seating" else "VIP experience", color = Muted, fontSize = 12.sp) }; Text("\$${when (tier) { "Premium" -> "95"; "VIP" -> "150"; else -> "55" }}", color = Ink, fontWeight = FontWeight.Bold) } } } }
            item { Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Ticket quantity", color = Ink, fontWeight = FontWeight.SemiBold); Text("Maximum 6 tickets", color = Muted, fontSize = 12.sp) }; IconButton(onClick = { if (quantity > 1) quantity-- }) { Icon(Icons.Default.Remove, null) }; Text("$quantity", color = Ink, fontWeight = FontWeight.Bold); IconButton(onClick = { if (quantity < 6) quantity++ }) { Icon(Icons.Default.Add, null) } } }
            item { Text("Contact information", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            item { OutlinedTextField(value = name, onValueChange = { name = it; error = "" }, modifier = Modifier.fillMaxWidth(), label = { Text("Full name") }, singleLine = true, shape = RoundedCornerShape(12.dp)) }
            item { OutlinedTextField(value = email, onValueChange = { email = it; error = "" }, modifier = Modifier.fillMaxWidth(), label = { Text("Email address") }, singleLine = true, shape = RoundedCornerShape(12.dp)) }
            item { Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(16.dp)) { Text("Payment summary", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp); PriceRow("Tickets ($quantity × $${"%.2f".format(unitPrice)})", subtotal); PriceRow("Service fee (12%)", fee); PriceRow("Estimated tax (5%)", tax); Divider(Modifier.padding(vertical = 8.dp)); PriceRow("Total", total, true) } } }
            item { Text("DEMO CHECKOUT • No payment details are collected and no real money will be charged.", color = Color(0xFF925A00), fontSize = 12.sp, lineHeight = 17.sp) }
            if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        }
        Button(onClick = { if (name.isBlank()) error = "Enter your name to continue." else if (!email.matches(Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"))) error = "Enter a valid email address." else onComplete(name.trim(), email.trim(), quantity, total, category) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp).height(54.dp), shape = RoundedCornerShape(12.dp)) { Text("Complete Demo Purchase • \$${"%.2f".format(total)}", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun PriceRow(label: String, amount: Double, bold: Boolean = false) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = if (bold) Ink else Muted, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal); Text("\$${"%.2f".format(amount)}", color = Ink, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium) } }

@Composable
private fun ConfirmationScreen(ticket: DemoTicket, onTickets: () -> Unit, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Pale).padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).background(Color(0xFFDDF8E8), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF16834A), modifier = Modifier.size(46.dp)) }
        Spacer(Modifier.height(16.dp)); Text("You're all set!", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("Your demo order is confirmed", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp)); TicketCard(ticket, onEmail = { }); Spacer(Modifier.height(12.dp)); Text("DEMO PURCHASE — NO PAYMENT WAS TAKEN. THIS TICKET IS NOT VALID FOR ENTRY.", color = Color(0xFF9A4F00), fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 17.sp)
        Spacer(Modifier.height(20.dp)); Button(onClick = onTickets, modifier = Modifier.fillMaxWidth()) { Text("View My Tickets") }; OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("Back to events") }
    }
}

@Composable
private fun TicketCard(ticket: DemoTicket, onEmail: (DemoTicket) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("ticketmaster", color = TMBlue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold); Text("DEMO TICKET", color = Color(0xFF9A4F00), fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            Divider(Modifier.padding(vertical = 12.dp)); Text(ticket.eventName, color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text("${ticket.date} • ${ticket.venue}", color = Muted, fontSize = 12.sp); Text(ticket.city, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(60.dp).background(Pale, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.QrCode2, null, tint = Navy, modifier = Modifier.size(45.dp)) }; Spacer(Modifier.width(12.dp)); Column { Text("${ticket.category} • ${ticket.quantity} ticket(s)", color = Ink, fontWeight = FontWeight.SemiBold); Text("Order #${ticket.orderId}", color = Muted, fontSize = 12.sp); Text("Holder: ${ticket.holder}", color = Muted, fontSize = 12.sp); Text("Demo total: $${"%.2f".format(ticket.total)}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp) } }
            Spacer(Modifier.height(12.dp)); Text("DEMO TICKET — NOT VALID FOR ENTRY", color = Color(0xFFB45309), fontWeight = FontWeight.Bold, fontSize = 11.sp); OutlinedButton(onClick = { onEmail(ticket) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Email, null); Spacer(Modifier.width(6.dp)); Text("Email event link") }
        }
    }
}

@Composable
private fun ProfileScreen(padding: PaddingValues, name: String, onName: (String) -> Unit, city: String, onCity: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding)) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(22.dp)) { Text("Profile", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Your Ticketmaster demo account", color = Color(0xFFD4E0F4), fontSize = 13.sp) }
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("Account details", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp); OutlinedTextField(value = name, onValueChange = onName, modifier = Modifier.fillMaxWidth(), label = { Text("Display name") }, singleLine = true); OutlinedTextField(value = city, onValueChange = onCity, modifier = Modifier.fillMaxWidth(), label = { Text("Preferred city") }, singleLine = true); Text("Demo mode", color = TMBlue, fontWeight = FontWeight.Bold); Text("This hackathon build simulates purchases. It is not an official Ticketmaster application, and its demo tickets do not grant venue entry.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp) }
    }
}

@Composable
private fun DetailLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = TMBlue, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Column { Text(label, color = Muted, fontSize = 11.sp); Text(value, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium) } } }

@Composable
private fun HeaderScreen(padding: PaddingValues, title: String, subtitle: String) { Column(Modifier.fillMaxWidth().padding(padding).background(Navy).padding(22.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp); Spacer(Modifier.height(5.dp)); Text(subtitle, color = Color(0xFFCBD7EE), fontSize = 13.sp) } }

@Composable
private fun EmptyState(title: String, body: String) { Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(68.dp).background(Color(0xFFE4ECFF), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.ConfirmationNumber, null, tint = TMBlue, modifier = Modifier.size(34.dp)) }; Spacer(Modifier.height(14.dp)); Text(title, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text(body, color = Muted, fontSize = 14.sp) } }

private fun saveTickets(prefs: android.content.SharedPreferences, tickets: List<DemoTicket>) {
    val array = JSONArray()
    tickets.forEach { t -> array.put(JSONObject().put("orderId", t.orderId).put("eventId", t.eventId).put("eventName", t.eventName).put("date", t.date).put("venue", t.venue).put("city", t.city).put("category", t.category).put("quantity", t.quantity).put("total", t.total).put("holder", t.holder).put("email", t.email)) }
    prefs.edit().putString("tickets", array.toString()).apply()
}

private fun loadTickets(prefs: android.content.SharedPreferences): List<DemoTicket> {
    return try {
        val array = JSONArray(prefs.getString("tickets", "[]"))
        (0 until array.length()).map { i -> val o = array.getJSONObject(i); DemoTicket(o.optString("orderId"), o.optString("eventId"), o.optString("eventName"), o.optString("date"), o.optString("venue"), o.optString("city"), o.optString("category", "Standard"), o.optInt("quantity", 1), o.optDouble("total", 0.0), o.optString("holder"), o.optString("email")) }
    } catch (_: Exception) { emptyList() }
}

private fun sampleEvents(): List<EventItem> = listOf(
    EventItem("demo1", "The Live Music Experience", "2026-11-14", "The Grand Arena", "New York", "Music", "From $45"),
    EventItem("demo2", "City Basketball Finals", "2026-11-18", "Metro Sports Center", "New York", "Sports", "From $35"),
    EventItem("demo3", "Comedy After Dark", "2026-11-21", "Riverside Theatre", "New York", "Comedy", "From $28"),
    EventItem("demo4", "Indie Sounds Festival", "2026-12-05", "Harbor Park", "New York", "Music", "From $60"),
    EventItem("demo5", "Broadway Spotlight", "2026-12-12", "Majestic Playhouse", "New York", "Theatre", "From $52"),
    EventItem("demo6", "Family Winter Spectacular", "2026-12-19", "City Hall Theatre", "New York", "Family", "From $32")
)
